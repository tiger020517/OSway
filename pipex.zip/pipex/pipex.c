#include "pipex.h"

int	main(int argc, char **argv, char **envp)
{
	int		fd[2];
	pid_t	pid1;

	if (argc == 5)
	{
		if (pipe(fd) < 0)
			error("Pipe 생성 실패..");
		pid1 = fork();
		if (pid1 < 0)
			error("Fork 실패..");
		if (pid1 == 0)
			process_1(argv, envp, fd);
		wait(NULL);
		process_2(argv, envp, fd);
	}
	else
	{
		write(2, "Error: Wrong number of arguments\n", 34);
		exit(EXIT_FAILURE);
	}
	return (0);
}

void	process_1(char **argv, char **envp, int *fd)
{
	int		filein;

	filein = open(argv[1], O_RDONLY, 0777);
	if (filein < 0)
		error("File 열기 실패..");
	dup2(fd[WRITE_END], STDOUT_FILENO);
	dup2(filein, STDIN_FILENO);
	close(fd[READ_END]);
	close(fd[WRITE_END]);
	close(filein);
	go(argv[2], envp);
}

void	process_2(char **argv, char **envp, int *fd)
{
	int		fileout;

	fileout = open(argv[4], O_WRONLY | O_CREAT | O_TRUNC, 0777);
	if (fileout < 0)
		error("File 열기 실패..");
	dup2(fd[READ_END], STDIN_FILENO);
	dup2(fileout, STDOUT_FILENO);
	close(fd[WRITE_END]);
	close(fd[READ_END]);
	close(fileout);
	go(argv[3], envp);
}

