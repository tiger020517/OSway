#include "./pipex.h"

void	go(char *argv, char **envp)
{
	char	**cmd;
	int 	i;
	char	*path;
	
	i = -1;
	cmd = ft_split(argv, ' ');
	path = find_path(cmd[0], envp);
	if (!path)	
	{
		ft_freetwodim(cmd);
		error("PATH 못 찾음..");
	}
	if (execve(path, cmd, envp) < 0)
	{
		free(path);
		ft_freetwodim(cmd);
		error("execve 실패..");
	}
}

char	*find_path(char *cmd, char **envp)
{
	char	**paths;
	char	*path;
	int		i;
	char	*part_path;

	i = 0;
	while (ft_strnstr(envp[i], "PATH", 4) == 0)
		i++;
	paths = ft_split(&envp[i][5], ':');
	i = -1;
	while (paths[++i])
	{
		part_path = ft_strjoin(paths[i], "/");
		path = ft_strjoin(part_path, cmd);
		free(part_path);
		if (access(path, F_OK | X_OK) == 0)
			return (path);
		free(path);
	}
	ft_freetwodim(paths);
	return (0);
}

void	error(char *msg)
{
	perror(msg);
	exit(EXIT_FAILURE);
}

void	ft_freetwodim(char **arr)
{
	int i;

	if (!arr)
		return;
	i = -1;
	while (arr[++i])
		free(arr[i]);
	free(arr);
}
/*
char **SplitArgs(char *input, char *args[])
{
	int no_arg;
	int	i;

	no_arg = 0;
	i = 0;
	while(i < ft_strlen(input))
	{
		while(ft_isspace(input[i]))
			i++;
		if(input[i] == 0)
			break;
		args[no_arg++] = &input[i];
		while (i < ft_strlen(input) && !ft_isspace(input[i]))
			i++;
		input[i] = 0;
		i++;
	}
	args[no_arg] = NULL;
	return (args);
}

int ft_isspace(char c)
{
	return (c == ' ' || c == '\t' || c == '\n' || c == '\v' || c == '\f' || c == '\r');
}
*/