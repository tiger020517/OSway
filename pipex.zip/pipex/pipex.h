#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <stdarg.h>
#include <fcntl.h>

#include "./libft/libft.h"

#define READ_END 0
#define WRITE_END 1

void	process_1(char **argv, char **envp, int *fd);
void	process_2(char **argv, char **envp, int *fd);

char	*find_path(char *cmd, char **envp);
void	error(char *msg);
void	go(char *argv, char **envp);
void	ft_freetwodim(char **arr);

/*
char	**SplitArgs(char *input, char *args[]);
int 	ft_isspace(char c);
*/